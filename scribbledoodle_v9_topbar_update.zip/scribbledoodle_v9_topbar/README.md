# ScribbleDoodle v9 Top Bar Update

This update redesigns the ScribbleDoodle document header and toolbar to feel more like a real document editor.

## Included in this update
- New top-left document icon
- Editable document title
- Favorite star button
- Menu row with File, Edit, View, Insert, Format, Tools, Extensions, and Help
- Toolbar with undo, redo, print, grammar check, text style dropdown, font dropdown, custom font upload, font size controls, bold, italic, underline, text color, highlight color, and alignment
- Bottom word-count and character-count panel
- Arrow toggle to hide or show the bottom stats panel
- Toolbar collapse button
- Print layout that hides the app UI and prints only the document content

## Notes
- This package is focused on the top bar and document layout update.
- Some advanced features can still be expanded later.
