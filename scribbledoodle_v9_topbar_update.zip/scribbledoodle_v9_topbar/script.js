const editor = document.getElementById('editor');
const favoriteBtn = document.getElementById('favoriteBtn');
const toolbarCollapseBtn = document.getElementById('toolbarCollapseBtn');
const toolbarRow = document.getElementById('toolbarRow');
const statsPanel = document.getElementById('statsPanel');
const statsToggleBtn = document.getElementById('statsToggleBtn');
const wordCount = document.getElementById('wordCount');
const charCount = document.getElementById('charCount');
const titlePreview = document.getElementById('titlePreview');
const docTitle = document.getElementById('docTitle');
const grammarBtn = document.getElementById('grammarBtn');
const styleSelect = document.getElementById('styleSelect');
const fontSelect = document.getElementById('fontSelect');
const fontUpload = document.getElementById('fontUpload');
const fontSizeInput = document.getElementById('fontSizeInput');
const textColorInput = document.getElementById('textColorInput');
const highlightColorInput = document.getElementById('highlightColorInput');
const alignSelect = document.getElementById('alignSelect');

const recentFonts = [];
const maxRecentFonts = 5;

function updateStats() {
  const text = editor.innerText.replace(/\n+/g, ' ').trim();
  const words = text ? text.split(/\s+/).length : 0;
  const chars = text.length;
  wordCount.textContent = String(words);
  charCount.textContent = String(chars);
  titlePreview.textContent = docTitle.value.trim() || 'Untitled document';
}

function setSelectionBlock(tagName) {
  document.execCommand('formatBlock', false, tagName);
  editor.focus();
}

function applyStyle(styleValue) {
  switch (styleValue) {
    case 'title':
      setSelectionBlock('h1');
      break;
    case 'heading1':
      setSelectionBlock('h2');
      break;
    case 'heading2':
      setSelectionBlock('h3');
      break;
    case 'heading3':
      setSelectionBlock('h4');
      break;
    case 'subtitle':
      setSelectionBlock('h5');
      break;
    default:
      setSelectionBlock('p');
      break;
  }
}

function refreshRecentFonts() {
  const recentGroup = document.getElementById('recentFontsGroup');
  recentGroup.innerHTML = '';
  recentFonts.forEach((fontName) => {
    const option = document.createElement('option');
    option.value = fontName;
    option.textContent = fontName;
    recentGroup.appendChild(option);
  });
}

function pushRecentFont(fontName) {
  const existingIndex = recentFonts.indexOf(fontName);
  if (existingIndex >= 0) {
    recentFonts.splice(existingIndex, 1);
  }
  recentFonts.unshift(fontName);
  if (recentFonts.length > maxRecentFonts) {
    recentFonts.pop();
  }
  refreshRecentFonts();
}

function applyFont(fontName) {
  editor.style.fontFamily = fontName;
  document.execCommand('fontName', false, fontName);
  pushRecentFont(fontName);
  fontSelect.value = fontName;
  editor.focus();
}

function applyAlignment(value) {
  const commands = {
    left: 'justifyLeft',
    center: 'justifyCenter',
    right: 'justifyRight',
    justify: 'justifyFull'
  };
  document.execCommand(commands[value], false);
  editor.focus();
}

function applyFontSize(size) {
  const safeSize = Math.max(8, Math.min(120, Number(size) || 16));
  fontSizeInput.value = String(safeSize);
  editor.style.fontSize = `${safeSize}px`;
  editor.focus();
}

function updateToolbarCollapseIcon() {
  toolbarCollapseBtn.textContent = toolbarRow.classList.contains('hidden') ? '⌄' : '⌃';
}

function updateStatsToggleIcon() {
  statsToggleBtn.textContent = statsPanel.classList.contains('collapsed') ? '▸' : '▾';
}

document.getElementById('undoBtn').addEventListener('click', () => {
  document.execCommand('undo', false);
  updateStats();
});

document.getElementById('redoBtn').addEventListener('click', () => {
  document.execCommand('redo', false);
  updateStats();
});

document.getElementById('printBtn').addEventListener('click', () => {
  window.print();
});

document.getElementById('boldBtn').addEventListener('click', () => {
  document.execCommand('bold', false);
  editor.focus();
});

document.getElementById('italicBtn').addEventListener('click', () => {
  document.execCommand('italic', false);
  editor.focus();
});

document.getElementById('underlineBtn').addEventListener('click', () => {
  document.execCommand('underline', false);
  editor.focus();
});

favoriteBtn.addEventListener('click', () => {
  favoriteBtn.classList.toggle('active');
});

toolbarCollapseBtn.addEventListener('click', () => {
  toolbarRow.classList.toggle('hidden');
  updateToolbarCollapseIcon();
});

statsToggleBtn.addEventListener('click', () => {
  statsPanel.classList.toggle('collapsed');
  updateStatsToggleIcon();
});

grammarBtn.addEventListener('click', () => {
  const text = editor.innerText;
  const cleaned = text
    .replace(/\bi\b/g, 'I')
    .replace(/\s{2,}/g, ' ')
    .replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => `${prefix}${letter.toUpperCase()}`);

  if (cleaned !== text) {
    editor.innerText = cleaned;
  }
  editor.focus();
  updateStats();
  grammarBtn.animate(
    [
      { transform: 'scale(1)' },
      { transform: 'scale(1.08)' },
      { transform: 'scale(1)' }
    ],
    { duration: 180 }
  );
});

styleSelect.addEventListener('change', (event) => {
  applyStyle(event.target.value);
});

fontSelect.addEventListener('change', (event) => {
  const selected = event.target.value;
  if (selected === '__upload__') {
    fontUpload.click();
    fontSelect.value = editor.style.fontFamily.replace(/"/g, '') || 'Arial';
    return;
  }
  applyFont(selected);
});

fontUpload.addEventListener('change', async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;

  const fontName = file.name.replace(/\.[^.]+$/, '');
  const fileUrl = URL.createObjectURL(file);

  const fontFace = new FontFace(fontName, `url(${fileUrl})`);
  try {
    await fontFace.load();
    document.fonts.add(fontFace);
    applyFont(fontName);
  } catch (error) {
    console.error('Font load failed:', error);
    alert('That font could not be loaded.');
  }
});

document.getElementById('decreaseFontBtn').addEventListener('click', () => {
  applyFontSize(Number(fontSizeInput.value) - 1);
});

document.getElementById('increaseFontBtn').addEventListener('click', () => {
  applyFontSize(Number(fontSizeInput.value) + 1);
});

fontSizeInput.addEventListener('change', (event) => {
  applyFontSize(event.target.value);
});

textColorInput.addEventListener('input', (event) => {
  document.execCommand('foreColor', false, event.target.value);
  editor.focus();
});

highlightColorInput.addEventListener('input', (event) => {
  document.execCommand('hiliteColor', false, event.target.value);
  editor.focus();
});

alignSelect.addEventListener('change', (event) => {
  applyAlignment(event.target.value);
});

docTitle.addEventListener('input', updateStats);
editor.addEventListener('input', updateStats);
editor.addEventListener('keyup', updateStats);
editor.addEventListener('mouseup', updateStats);

applyFont('Arial');
applyFontSize(16);
updateToolbarCollapseIcon();
updateStatsToggleIcon();
updateStats();
